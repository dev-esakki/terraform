/* eslint-disable no-console */
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-west-2' });
const docClient = DynamoDBDocumentClient.from(client);

async function invokeDB() {
  const params = {
    TableName: 'customers',
    FilterExpression: '#status = :status',
    ExpressionAttributeNames: {
      '#status': 'status',
    },
    ExpressionAttributeValues: {
      ':status': true,
    },
  };
  const data = await docClient.send(new ScanCommand(params));
  const activeList = data.Items;
  return activeList;
}

exports.handler = async () => {
  const result = await invokeDB();
  console.log(result);
  return result;
};
