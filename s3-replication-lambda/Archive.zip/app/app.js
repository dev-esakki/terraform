const { S3Client, PutBucketReplicationCommand, DeleteBucketReplicationCommand, GetBukcetReplicationCommand } = require('@aws-sdk/client-s3');

exports.handler = async (event, context) => {
  console.log('Event:', JSON.stringify(event, null, 2));

  const s3 = new S3Client({});
  const props = event.ResourceProperties;
  console.log("props =======================",props);
  const sourceBucket = props.SourceBucket;
  const destinationBucketArn = props.DestinationBucketArn;
  const replicationRoleArn = props.ReplicationRoleArn;

  const getReplication = new GetBukcetReplicationCommand({ Bucket: sourceBucket });
  console.log("getReplication =======================",getReplication);
  const existingReplication = await s3.send(getReplication)
  const rules = existingReplication.ReplicationConfiguration?.Rules || [];
  const ruleExists = rules.some(rule => rule.Destination?.Bucket === destinationBucketArn);

  if (ruleExists) {
    console.log(`Replication rule already exists for destination bucket: ${destinationBucketArn}`);
    return { Status: 'SUCCESS' };
  }
  const replicationConfig = {
    Role: replicationRoleArn,
    Rules: [
      {
        ID: 'CustomCFNReplicationRule',
        Status: 'Enabled',
        Priority: 1,
        DeleteMarkerReplication: {
          Status: 'Enabled'
        },
        Filter: {},
        Destination: {
          Bucket: destinationBucketArn,
          StorageClass: 'STANDARD'
        }
      }
    ]
  };

  try {
    if (event.RequestType === 'Delete') {
      await s3.send(new DeleteBucketReplicationCommand({ Bucket: sourceBucket }));
      console.log(`Replication configuration deleted for bucket: ${sourceBucket}`);
    } else {
      await s3.send(new PutBucketReplicationCommand({
        Bucket: sourceBucket,
        ReplicationConfiguration: replicationConfig
      }));
      console.log(`Replication configuration set for bucket: ${sourceBucket}`);
    }

    return { Status: 'SUCCESS' };
  } catch (error) {
    console.error('Error:', error);
  }
};
